<footer class="mt-5">
   <div class="container">
      <div class="row">
         <div class="col-md-3">
            <div class="footer-head">
               <h5 class="widgetheading">Jevelin</h5>
               <p>Lorem ipsum dolor sit amet.
                 <br>consectetur adipiscing elit. Nam at</p>
                 <ul class="list-4">
                   <li><i class="fa fa-linkedin" aria-hidden="true"></i></li>
                   <li><i class="fa fa-twitter" aria-hidden="true"></i></li>
                   <li><i class="fa fa-facebook" aria-hidden="true"></i></li>
                 </ul>
            </div>
         </div>
         <div class="col-md-3">
            <div class="footer-head ml-4">
               <h5 class="widgetheading">Explore</h5>
               <ul class="link-list">
                  <li><a href="#">Cookies</a></li>
                  <li><a href="#">About</a></li>
                  <li><a href="#">Privacy policy</a></li>
                  <li><a href="#">Licences</a></li>
               </ul>
            </div>
         </div>
         <div class="col-md-3">
            <div class="footer-head ml-4">
               <h5 class="widgetheading">Marketing</h5>
               <ul class="link-list">
                  <li><a href="#">Timeline</a></li>
                  <li><a href="#">News</a></li>
                  <li><a href="#">Insight</a></li>
                  <li><a href="#">Licensing</a></li>
               </ul>
            </div>
         </div>
         <div class="col-md-3">
            <div class="footer-head ml-4">
               <h5 class="widgetheading">Categories</h5>
               <ul class="link-list">
                  <li><a href="#">About</a></li>
                  <li><a href="#">Strategy</a></li>
                  <li><a href="#">Terms & Conditions</a></li>
                  <li><a href="#">Services</a></li>
               </ul>
            </div>
         </div>
      </div>
   </div>
   <div id="sub-footer">
      <div class="container">
         <div class="row">
            <div class="col-md-6">
               <div class="copyright mt-5">
                  <p><span>Copyright 2019 Shufflehoun. All rights reserved.</span></p>
               </div>
            </div>
            <div class="col-md-6">
                <ul class="link-list-1 mt-5">
                  <li><a href="#">Home</a></li>
                  <li><a href="#">About</a></li>
                  <li><a href="#">Services</a></li>
                  <li><a href="#">Reviews</a></li>
                  <li><a href="#">Contact</a></li>
               </ul>
            </div>
         </div>
      </div>
   </div>
</footer>